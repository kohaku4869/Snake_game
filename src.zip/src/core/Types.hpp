#pragma once
#include <SFML/System.hpp>
using Cell = sf::Vector2i;   // ô lưới