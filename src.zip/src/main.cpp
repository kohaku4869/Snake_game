#include "Game.hpp"

int main() {
    Game g;
    g.run();
    return 0;
}
